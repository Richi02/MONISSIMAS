<?php
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\EmpresasModel;
use App\Models\RegistrosModel;
class Empresas extends Controller {
    public function index(){
        $request = \Config\Services::request();
        $validation = \Config\Services::validation();
        $headers = $request->getHeaders();
        $model = new RegistrosModel();
        $registro = $model->where('estado', 1)->findAll();
        
        foreach($registro as $key=>$value){
            if(array_key_exists('Authorization',$headers)&& !empty($headers['Authorization'])){
                if($request->getHeader('Authorization')=='Authorization: Basic '.base64_encode($value['cliente_id'].':'.$value['llave_secreta'])){
                    $model = new EmpresasModel();
                    $empresa = $model->where('estado',1)->findAll();
                    if(!empty($empresa)){
                        $data = array(
                            "Status"=>200, 
                            "Total de registros"=>count($empresa),
                            "Detalle"=>$empresa
                        );
                    }
                    else{
                        $data = array(
                            "Status"=>404,
                            "Total de registros"=>0,
                            "Detalles"=>"No hay registros"
                        );
                    }
                    return json_encode($data, true);
                }   
                else{
                    $data = array(
                        "Status"=>404,
                        "Detalles"=>"El token es incorrecto"
                    );
                }
            }
            else{
                $data = array(
                    "Status"=>404,
                    "Detalles"=>"No posee autorización"
                );
            }    
        }
        return json_encode($data, true);
    }
    public function show($id){
        $request = \Config\Services::request();
        $validation = \Config\Services::validation();
        $headers = $request->getHeaders();
        $model = new RegistrosModel();
        $registro = $model->where('estado', 1)->findAll();
        
        foreach($registro as $key=>$value){
            if(array_key_exists('Authorization',$headers)&& !empty($headers['Authorization'])){
                
                if($request->getHeader('Authorization')=='Authorization: Basic '.base64_encode($value['cliente_id'].':'.$value['llave_secreta'])){
                    $model = new EmpresasModel();
                    $empresa = $model->where('estado',1)->find($id);
                    //var_dump($empresa); die;
                    if(!empty($empresa)){
                        $data = array(
                            "Status"=>200, "Detalle"=>$empresa);
                    }
                    else{
                        $data = array(
                            "Status"=>404,
                            "Detalles"=>"No hay registros"
                        );
                    }
                    return json_encode($data, true);
                }   
                else{
                    $data = array(
                        "Status"=>404,
                        "Detalles"=>"El token es incorrecto"
                    );
                }
            }
            else{
                $data = array(
                    "Status"=>404,
                    "Detalles"=>"No posee autorización"
                );
            }    
        }
        return json_encode($data, true);
    }
    public function create(){
        $request = \Config\Services::request();
        $validation = \Config\Services::validation();
        $headers = $request->getHeaders();
        $model = new RegistrosModel();
        $registro = $model->where('estado', 1)->findAll();
        foreach($registro as $key=>$value){
            if(array_key_exists('Authorization',$headers)&& !empty($headers['Authorization'])){
                if($request->getHeader('Authorization')=='Authorization: Basic '.base64_encode($value['cliente_id'].':'.$value['llave_secreta'])){
                    $datos = array(
                        "empresanombre"=>$request->getVar("empresanombre"),
                        "empresaTelefono"=>$request->getVar("empresaTelefono"),
                        "empresaCorreo"=>$request->getVar("empresaCorreo"),
                        "provincia"=>$request->getVar("provincia"),
                        "distrito"=>$request->getVar("distrito"),
                        "departamento"=>$request->getVar("departamento")
                    );
                    if(!empty($datos)){
                        $validation->setRules([
                            "empresanombre"=>'required|string|max_length[255]',
                            "empresaTelefono"=>'required|string|max_length[255]',
                            "empresaCorreo"=>'required|string|max_length[255]',
                            "provincia"=>'required|string|max_length[255]',
                            "distrito"=>'required|string|max_length[255]',
                            "departamento"=>'required|string|max_length[255]'
                        ]);
                        $validation->withRequest($this->request)->run();
                        if($validation->getErrors()){
                            $errors = $validation->getErrors();
                            $data = array("Status"=>404, "Detalle"=>$errors);
                            return json_encode($data, true);
                        }
                        else{
                            $datos = array(
                                    "empresanombre"=>$datos["empresanombre"],
                                    "empresaTelefono"=>$datos["empresaTelefono"],
                                    "empresaCorreo"=>$datos["empresaCorreo"],
                                    "provincia"=>$datos["provincia"],
                                    "distrito"=>$datos["distrito"],
                                    "departamento"=>$datos["departamento"]
                            );
                            $model = new EmpresasModel();
                            $empresa = $model->insert($datos);
                            $data = array(
                                "Status"=>200,
                                "Detalle"=>"Registro exitoso"
                            );
                            return json_encode($data, true);
                        }
                    }
                    else{
                        $data = array(
                            "Status"=>400,
                            "Detalle"=>"Registro con errores"
                        );
                        return json_encode($data, true);
                    }
                }
                else{
                    $data = array(
                        "Status"=>404,
                        "Detalles"=>"El token es incorrecto"
                    );
                }
            }
            else{
                $data = array(
                    "Status"=>404,
                    "Detalles"=>"No posee autorización"
                );
            }
        }
        return json_encode($data, true);
      
    }
    public function update($id){
        $request = \Config\Services::request();
        $validation = \Config\Services::validation();
        $headers = $request->getHeaders();
        $model = new RegistrosModel();
        $registro = $model->where('estado', 1)->findAll();
        foreach($registro as $key=>$value){
            if(array_key_exists('Authorization',$headers)&& !empty($headers['Authorization'])){
                if($request->getHeader('Authorization')=='Authorization: Basic '.base64_encode($value['cliente_id'].':'.$value['llave_secreta'])){
                    $datos = $this->request->getRawInput();
                    if(!empty($datos)){
                        $validation->setRules([
                            "empresanombre"=>'required|string|max_length[255]',
                            "empresaTelefono"=>'required|string|max_length[255]',
                            "empresaCorreo"=>'required|string|max_length[255]',
                            "provincia"=>'required|string|max_length[255]',
                            "distrito"=>'required|string|max_length[255]',
                            "departamento"=>'required|string|max_length[255]'
                        ]);
                        $validation->withRequest($this->request)->run();
                        if($validation->getErrors()){
                            $errors = $validation->getErrors();
                            $data = array("Status"=>404, "Detalle"=>$errors);
                            return json_encode($data, true);
                        }
                        else{
                            $model = new EmpresasModel();
                            $empresa = $model->find($id);
                            if(is_null($empresa)){
                                $data = array(
                                    "Status"=>404,
                                    "Detalles"=>"Registro no existe"
                                );
                                return json_encode($data, true);
                            }
                            else{
                                $datos = array(
                                    "empresanombre"=>$datos["empresanombre"],
                                    "empresaTelefono"=>$datos["empresaTelefono"],
                                    "empresaCorreo"=>$datos["empresaCorreo"],
                                    "provincia"=>$datos["provincia"],
                                    "distrito"=>$datos["distrito"],
                                    "departamento"=>$datos["departamento"]
                            );
                            $model = new EmpresasModel();
                            $empresa = $model->update($id, $datos);
                            $data = array(
                                "Status"=>200,
                                "Detalles"=>"Datos actualizados"
                            );
                            return json_encode($data, true);
                            }
                        }
                    }
                    else{
                        $data = array(
                            "Status"=>400,
                            "Detalle"=>"Registro con errores"
                        );
                        return json_encode($data, true);
                    }
                }
                else{
                    $data = array(
                        "Status"=>404,
                        "Detalles"=>"El token es incorrecto"
                    );
                }
            }
            else{
                $data = array(
                    "Status"=>404,
                    "Detalles"=>"No posee autorización"
                );
            }
        }
        return json_encode($data, true);   
    }
    public function delete($id){
        $request = \Config\Services::request();
        $validation = \Config\Services::validation();
        $headers = $request->getHeaders();
        $model = new RegistrosModel();
        $registro = $model->where('estado', 1)->findAll();
        
        foreach($registro as $key=>$value){
            if(array_key_exists('Authorization',$headers)&& !empty($headers['Authorization'])){
                
                if($request->getHeader('Authorization')=='Authorization: Basic '.base64_encode($value['cliente_id'].':'.$value['llave_secreta'])){
                    $model = new EmpresasModel();
                    $empresa = $model->where('estado',1)->find($id);
                    //var_dump($empresa); die;
                    if(!empty($empresa)){
                        $datos = array("estado"=>0);
                        $empresa = $model->update($id, $datos);
                        $data = array(
                            "Status"=>200, 
                            "Detalle"=>"Se ha eliminado el registro"
                        );
                    }
                    else{
                        $data = array(
                            "Status"=>404,
                            "Detalles"=>"No hay registros");
                    }
                    return json_encode($data, true);
                }   
                else{
                    $data = array(
                        "Status"=>404,
                        "Detalles"=>"El token es incorrecto"
                    );
                }
            }
            else{
                $data = array(
                    "Status"=>404,
                    "Detalles"=>"No posee autorización"
                );
            }    
        }
        return json_encode($data, true);
    }
    
}